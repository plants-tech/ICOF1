#include "core/InputSource.hpp"

InputSource::InputSource() {}
